<script>
  function handleSuspendModal(serverId, actionUrl) {
    Swal.fire({
      title: "{{ __('Reason for Suspension') }}",
      showCancelButton: true,
      confirmButtonText: "{{ __('Submit') }}",
      cancelButtonText: "{{ __('Cancel') }}",
      reverseButtons: true,
      input: "textarea",
      inputPlaceholder: "SUMMER",
      inputLabel: "Reason",
      inputAttributes: {
        autocomplete: "off",
        name: "reason"
      },
      showLoaderOnConfirm: true,
      preConfirm: async (reason) => {
        const formData = new FormData();
        formData.append("reason", reason);
        formData.append("_token", "{{ csrf_token() }}");
        formData.append("server_id", serverId);

        try {
          const response = await fetch(actionUrl, {
            method: "POST",
            "headers": {
              "Content-Type": "application/x-www-form-urlencoded",
            },
            body: new URLSearchParams(formData)
          });
          if (response.redirected) window.location.href = response.url
          return;
        } catch (error) {
          Swal.showValidationMessage(`Request failed: ${error}`);
        }
      },

      allowOutsideClick: () => !Swal.isLoading()
    })
  }
  $(document).ready(function() {
    $(document).on('click', '.suspend-btn', function() {
      const serverId = $(this).data('server-id');
      const actionUrl = $(this).data('action');

      handleSuspendModal(serverId, actionUrl);
    });
  });
</script>

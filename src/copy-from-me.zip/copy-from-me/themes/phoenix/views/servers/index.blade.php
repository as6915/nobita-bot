@extends('layouts.main')

@section('content')
  <div class="container mx-auto grid px-6" x-data="{ server_id: null }">

    <div class="mb-4 justify-between py-6 sm:flex">

      <h2 class="text-xl font-semibold text-gray-700 dark:text-gray-200">
        {{ __('Servers') }}
      </h2>

      @php
        $user = Auth::user();
        if ($user->Servers->count() >= $user->server_limit) {
            $btnTooltip = 'Server limit reached!';
            $btnDisabled = true;
        } elseif (!$user->can('user.server.create')) {
            $btnTooltip = 'No Permission!';
            $btnDisabled = true;
        } else {
            $btnTooltip = null;
            $btnDisabled = false;
        }
      @endphp

      <div class="flex gap-4">
        <x-tooltip :content="$btnTooltip" class="border-none" pos="bottom">
          <button @disabled($btnDisabled) title="{{ $btnTooltip }}"
            class="focus:shadow-outline-purple rounded-md border border-transparent bg-primary-600 px-3 py-1 text-sm font-medium leading-5 text-white transition-colors duration-150 hover:bg-primary-700 focus:outline-none active:bg-primary-600 disabled:cursor-not-allowed disabled:opacity-50"
            onclick="window.location.href = '{{ route('servers.create') }}'">
            {{ __('Create Server') }}
          </button>
        </x-tooltip>
        @if (Auth::user()->Servers->count() > 0 && !empty($phpmyadmin_url))
          <a class="focus:shadow-outline-purple focus:shadow-outline-purple rounded-md border border-transparent bg-gray-600 px-3 py-1 text-sm font-medium leading-5 !text-gray-800 !no-underline transition-colors duration-150 hover:bg-gray-600/50 focus:outline-none focus:ring focus:ring-gray-200 focus:ring-opacity-50 active:bg-gray-600 disabled:pointer-events-none disabled:cursor-not-allowed dark:!text-white"
            href="{{ $phpmyadmin_url }}" target="_blank">
            {{ __('Database') }}
          </a>
        @endif
      </div>
    </div>

    <div class="mb-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      @forelse ($servers as $server)
        @if ($server->location && $server->node && $server->nest && $server->egg)
          <div class="min-w-0 max-w-[400px] rounded-lg bg-white p-4 shadow-sm dark:bg-gray-800">
            <h2 class="text-2xl font-semibold text-gray-700 dark:text-gray-100">{{ $server->name }}
            </h2>
            <div class="w-full rounded-lg shadow-sm">
              <table class="whitespace-no-wrap w-full">
                <thead>
                  <tr
                    class="border-b bg-gray-50 text-left text-xs font-semibold uppercase tracking-wide text-gray-500 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400">
                    <th class="px-4 py-3">{{ __('Resources') }}</th>
                    <th class="px-4 py-3">{{ __('Details') }}</th>
                  </tr>
                </thead>
                <tbody class="divide-y bg-white dark:divide-gray-700 dark:bg-gray-800">
                  <tr class="text-gray-700 dark:text-gray-400">
                    <td class="px-4 py-3">
                      <div class="flex items-center text-sm">
                        <p class="font-semibold">
                          {{ __('Status') }}
                        </p>
                      </div>
                    </td>
                    <td class="px-4 py-3 text-sm">
                      @if ($server->suspended)
                        <span
                          class="rounded-full bg-red-100 px-2 py-1 text-xs font-semibold leading-tight text-red-700 dark:bg-red-500/20 dark:text-red-500">
                          {{ __('Suspended') }}
                        </span>
                      @elseif($server->canceled)
                        <span
                          class="rounded-full bg-yellow-100 px-2 py-1 text-xs font-semibold leading-tight text-yellow-700 dark:bg-yellow-500/20 dark:text-yellow-500">
                          {{ __('Canceled') }}
                        </span>
                      @else
                        <span
                          class="rounded-full bg-green-100 px-2 py-1 text-xs font-semibold leading-tight text-green-700 dark:bg-green-500/20 dark:text-green-500">
                          {{ __('Active') }}
                        </span>
                      @endif
                    </td>
                  </tr>
                  <tr class="text-gray-700 dark:text-gray-400">
                    <td class="px-4 py-3">
                      <div class="flex items-center text-sm">
                        <p class="font-semibold">
                          {{ __('Location') }}
                        </p>
                      </div>
                    </td>
                    <td class="px-4 py-3 text-sm">
                      {{ $server->location }}
                    </td>
                  </tr>
                  <tr>
                    <td class="px-4 py-3">
                      <div class="flex items-center text-sm">
                        <p class="font-semibold">
                          {{ __('Node') }}
                        </p>
                      </div>
                    </td>
                    <td class="px-4 py-3 text-sm">
                      {{ $server->node }}
                    </td>
                  </tr>
                  <tr>
                    <td class="px-4 py-3">
                      <div class="flex items-center text-sm">
                        <p class="font-semibold">
                          {{ __('Software') }}
                        </p>
                      </div>
                    </td>
                    <td class="px-4 py-3 text-sm">
                      {{ $server->nest }}, {{ $server->egg }}
                    </td>
                  </tr>
                  <tr>
                    <td class="px-4 py-3">
                      <div class="flex items-center text-sm">
                        <p class="font-semibold">
                          {{ __('Next Billing Cycle') }}
                        </p>
                      </div>
                    </td>
                    <td class="flex items-center px-4 py-3 text-sm">
                      @if ($server->suspended || $server->canceled)
                        -
                      @else
                        @switch($server->product->billing_period)
                          @case('monthly')
                            {{ \Carbon\Carbon::parse($server->last_billed)->addMonth()->toDayDateTimeString() }}
                          @break

                          @case('weekly')
                            {{ \Carbon\Carbon::parse($server->last_billed)->addWeek()->toDayDateTimeString() }}
                          @break

                          @case('daily')
                            {{ \Carbon\Carbon::parse($server->last_billed)->addDay()->toDayDateTimeString() }}
                          @break

                          @case('hourly')
                            {{ \Carbon\Carbon::parse($server->last_billed)->addHour()->toDayDateTimeString() }}
                          @break

                          @case('quarterly')
                            {{ \Carbon\Carbon::parse($server->last_billed)->addMonths(3)->toDayDateTimeString() }}
                          @break

                          @case('half-annually')
                            {{ \Carbon\Carbon::parse($server->last_billed)->addMonths(6)->toDayDateTimeString() }}
                          @break

                          @case('annually')
                            {{ \Carbon\Carbon::parse($server->last_billed)->addYear()->toDayDateTimeString() }}
                          @break

                          @default
                            {{ __('Unknown') }}
                        @endswitch
                      @endif
                    </td>
                  </tr>
                  <tr>
                    <td class="px-4 py-3">
                      <div class="flex items-center text-sm">
                        <p class="font-semibold">
                          {{ __('Resource plan') }}
                        </p>
                      </div>
                    </td>
                    <td class="flex items-center gap-2 px-4 py-3 text-sm">
                      {{ $server->product->name }}

                      <x-tooltip html pos="top" class="border-none">
                        @slot('content')
                          <p class="text-left">
                            {{ __('CPU') }}: {{ $server->product->cpu / 100 }} {{ __('vCores') }} <br />
                            {{ __('RAM') }}: {{ $server->product->memory }} MB <br />
                            {{ __('Disk') }}: {{ $server->product->disk }} MB <br />
                            {{ __('Backups') }}: {{ $server->product->backups }} <br />
                            {{ __('MySQL Databases') }}: {{ $server->product->databases }} <br />
                            {{ __('Allocations') }}: {{ $server->product->allocations }} <br />
                            {{ __('OOM Killer') }}: {{ $server->product->oom_killer ? __('enabled') : __('disabled') }}
                            <br />
                            {{ __('Billing Period') }}: {{ $server->product->billing_period }}
                          </p>
                        @endslot
                        <x-icon icon="ph:info-bold" width="20" height="20" class="ml-1 mt-1" />
                      </x-tooltip>
                    </td>
                  </tr>
                  <tr>
                    <td class="px-4 py-3">
                      <div class="flex items-center text-sm">
                        <p class="font-semibold">
                          {{ __('Price') }}
                          <span class="font-normal text-gray-600 dark:text-gray-400/75">
                            ({{ $credits_display_name }})
                          </span>
                        </p>
                      </div>
                    </td>
                    <td class="flex items-center gap-2 px-4 py-3 text-sm">
                      {{ $server->product->display_price }}
                      <span class="font-normal text-gray-600 dark:text-gray-400/75">
                        @if ($server->product->billing_period == 'monthly')
                          {{ __('per Month') }}
                        @elseif($server->product->billing_period == 'half-annually')
                          {{ __('per 6 Months') }}
                        @elseif($server->product->billing_period == 'quarterly')
                          {{ __('per 3 Months') }}
                        @elseif($server->product->billing_period == 'annually')
                          {{ __('per Year') }}
                        @elseif($server->product->billing_period == 'weekly')
                          {{ __('per Week') }}
                        @elseif($server->product->billing_period == 'daily')
                          {{ __('per Day') }}
                        @elseif($server->product->billing_period == 'hourly')
                          {{ __('per Hour') }}
                        @endif
                      </span>

                      <x-tooltip html pos="top" class="border-none">
                        @slot('content')
                          {{ __('Your') . ' ' . $credits_display_name . ' ' . __('are reduced') . ' ' . $server->product->billing_period . '. ' }}
                          <br />
                          {{ __('This however calculates to ') . Currency::formatForDisplay($server->product->getMonthlyPrice()) . ' ' . $credits_display_name . ' ' . __('per Month') }}
                        @endslot
                        <x-icon icon="ph:info-bold" width="20" height="20" class="ml-1 mt-1" />
                      </x-tooltip>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div class="mt-4 flex justify-evenly gap-4">
              <a href="{{ $pterodactyl_url }}/server/{{ $server->identifier }}" target="__blank"
                class="focus:shadow-outline-purple flex w-full items-center justify-center rounded-lg border-2 border-primary-600 px-4 py-3 text-center text-sm font-medium leading-5 text-primary-600 transition-colors duration-150 hover:bg-primary-600 hover:text-white focus:outline-none active:bg-primary-600 dark:text-white">
                {{ __('Manage') }}
                <svg class="ml-2 h-4 w-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                  <path stroke-linecap="round" stroke-linejoin="round"
                    d="M13.5 6H5.25A2.25 2.25 0 003 8.25v10.5A2.25 2.25 0 005.25 21h10.5A2.25 2.25 0 0018 18.75V10.5m-10.5 6L21 3m0 0h-5.25M21 3v5.25">
                  </path>
                </svg>
              </a>
              <a href="{{ route('servers.show', ['server' => $server->id]) }}"
                class="focus:shadow-outline-purple w-full rounded-lg border-2 border-primary-600 px-4 py-3 text-center text-sm font-medium leading-5 text-primary-600 transition-colors duration-150 hover:bg-primary-600 hover:text-white focus:outline-none active:bg-primary-600 dark:text-white">
                {{ __('Settings') }}
              </a>
            </div>
          </div>
        @endif
        @empty
          <div class="min-w-0 rounded-lg bg-white p-4 shadow-sm dark:bg-gray-800">
            <h4 class="font-semibold text-gray-600 dark:text-gray-300">
              No Servers Found!
            </h4>
          </div>
        @endforelse
      </div>

    </div>
  @endsection
